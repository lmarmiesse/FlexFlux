#!/bin/bash


source config

eval "java -Djava.library.path=$CPLEX_shared_library:$GLPK_shared_library -cp FlexFlux.jar:$CPLEX_JAR:$GLPK_JAR parsebionet.applications.flux.flexflux.gui.GraphicalFlexflux"
