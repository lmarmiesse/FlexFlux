#!/bin/bash


foo=""
for i in `seq 2 $#`
do
	if [[ "${!i}" == *\ * ]]
	then
	
	foo="$foo \"${!i}\"" 
	else
	foo="$foo ${!i}" 
	fi
    
done

source config

eval "java -Djava.library.path=$CPLEX_shared_library:$GLPK_shared_library -cp FlexFlux.jar:$CPLEX_JAR:$GLPK_JAR parsebionet.applications.flux.flexflux.Flexflux$1 $foo"
