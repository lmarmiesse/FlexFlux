FlexFlux installtion


For FlexFlux to work, you must have already installed a solver.
At this point, FlexFlux supports CPLEX and GLPK.


LINUX


1) make Flexflux.sh executable by typing the command:

chmod +x Flexflux.sh

2) Test your solvers by typing :

./FlexFlux.sh Test

If a solver is OK, you are all set ! Skip step 3), you can use FlexFlux.

If no solver is OK, go to step 3).


3) Open the configuration file : config

Set the right value(s) for your solver, ignore the others.

Try the ./FlexFlux.sh Test again.


4) Lunch the analysis you want by typing : 

./FlexFlux.sh your_analysis your_parameters

Example : 

./FlexFlux.sh FBA -s network.xml -cond conditions.txt
